const http = require('http'),
      fs = require('fs'),
      
      path = require('path'),
      
      loadStatic = require("./custom_modules/load_static_file.js"),
      
      reg_Insert_data = require("./custom_modules/reg_insert_data.js"),
      
      //login = require("./custom_modules/login_data.js"),
      
      mysql = require("mysql"),
      
      formidable = require("formidable"),

      util = require('util'),
      server = http.createServer();

var loginData, loginMail, baseData;

var photo_path = [];
    
var i = 0;


const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

var loginData, loginMail, baseData, loge;

con.query("CREATE DATABASE IF NOT EXISTS slide_db", (err, result) => {
    if (err) throw err;
    console.log('Database slide_db created');
});


con.query("use slide_db", (err, result) => {
    if (err) throw err;
    console.log("slide_db is using");
});


con.query('CREATE TABLE IF NOT EXISTS slide_tab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255), photos VARCHAR(10000))', (err, result) => {
    if (err) throw err;
    console.log("slide_tab created");
    });

server.on("request", (req, res) => {
    if (req.url == "/registration") {
        if (req.method == "POST" && req.url == "/registration") {
            req.on("data", (chunk) => {
                reg_Insert_data(chunk, res, con);
            })
        }
        else {
        loadStatic(req, res, './registration', './registration.html');
        }
    }
    
    else if (req.url == "/login") {
        if (req.method == "POST" && req.url == "/login"){
            req.on("data", (chunk) => {
                //login(chunk, res, loginData, loginMail, baseData, con);
                //loge = JSON.parse(chunk);
             
                
                     console.log(JSON.parse(chunk));
    
    loginData = JSON.parse(chunk);
                loginMail = loginData["mail"];

                //var sql = "SELECT * FROM rgtab WHERE mail = " + mysql.escape(loginMail);
                var sql = "SELECT * FROM slide_tab WHERE mail = ?";

                var logValue = [loginMail];

                con.query(sql, [logValue], (err, result) => {
                    if (err) throw err;
                    baseData = result;
                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] == baseData[0].password)) {
                        photo_path = [];
                        res.end("Autorization was succesfully.");
                    }

                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] != baseData[0].password)) {
                        res.end("Wrong password. Please, type correct password.")
                    }

                    if (typeof(baseData[0]) == "undefined") {
                        res.end("There is no user with such as email.")
                    }
                });
            })
        }
        else {
        loadStatic(req, res, "./login", "./login.html");
        }
    }
    
    else if (req.url == "/profile") {
        loadStatic(req, res, "./profile", "./profile.html");
    }
    
    else if (req.url == "/login?") {
        res.write("<h1>404 NOT FOUND</h1>");
        res.write("<a href='http://localhost:4448/login'>Login Page</a>");
        res.end();
    }
    else if (req.url == "/profile_photos") {
        if (req.method.toLowerCase() == "post") {
            var form = new formidable.IncomingForm();
            
            form.type = true;
            
            form.uploadDir = "./photo_server";
            
            form.parse(req, function(err, fields, files) {
                res.writeHead(200, {'content-type': 'text/plain'});
                
                var oldpath = files.upload.path;
                
                var direct = files.upload.path.slice(0, 13);
                
                var newpath = direct + "image" + i++;
                
                photo_path.push(newpath);
                
                fs.rename(oldpath, newpath, (err) => {
                    if (err) throw err;
                    console.log("Image's name have changed on " + " " + newpath);
                });
                
                var user_photos = baseData[0].photos + "," + photo_path.join(",").slice(0);
            
                var photo_setting = user_photos;
                
                var wheringId = baseData[0].id;
                
                var update_photos = "UPDATE slide_tab SET photos= ? WHERE id= ?"
                
                con.query(update_photos, [photo_setting, wheringId], (err, result) =>{
                          if (err) throw err;
                console.log("Photos updated");
                          });
                          
                res.write('received upload:\n\n');
                
                        
                res.end(util.inspect({fields: fields, files: files}));
            });
            return;
        }
        else {
            loadStatic(req, res, "./profile_photos", "./profile_photos.html");
        }
    }
    else if (req.url == "/login_user") {
        var select_login_user = "SELECT * from slide_tab where id= ?"
            con.query(select_login_user, [baseData[0].id], (err, result) => {
            if (err) throw err;
            res.write(JSON.stringify(result[0]));
                res.end();
        })
    }
     else if (req.url == "/all_users") {
            con.query("SELECT * from slide_tab", (err, result) => {
            if (err) throw err;
            res.write(JSON.stringify(result));
                res.end();
        })
    }
    else {
        loadStatic(req, res, './', './index.html');
    }
}).listen(4448);



const http = require('http');

const fs = require('fs');

const path = require('path');

const loadStatic = require("./custom_modules/load_static_file.js");

const reg_Insert_data = require("./custom_modules/reg_insert_data.js");

const login = require("./custom_modules/login_data.js");

const mysql = require("mysql");

const server = http.createServer();

var loginData, loginMail, baseData;


const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

var loginData, loginMail, baseData;

con.query("CREATE DATABASE IF NOT EXISTS slide_db", (err, result) => {
    if (err) throw err;
    console.log('Database slide_db created');
});


con.query("use slide_db", (err, result) => {
    if (err) throw err;
    console.log("slide_db is using");
});


con.query('CREATE TABLE IF NOT EXISTS slide_tab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255))', (err, result) => {
    if (err) throw err;
    console.log("slide_tab created");
    });

server.on("request", (req, res) => {
    if (req.url == "/registration") {
        if (req.method == "POST" && req.url == "/registration") {
            req.on("data", (chunk) => {
                reg_Insert_data(chunk, res, con);
            })
        }
        else {
        loadStatic(req, res, './registration', './registration.html');
        }
    }
    else if (req.url == "/login") {
        if (req.method == "POST" && req.url == "/login"){
            req.on("data", (chunk) => {
                login(chunk, res, loginData, loginMail, baseData, con);
            })
        }
        else {
        loadStatic(req, res, "./login", "./login.html");
        }
    }
    else {
        loadStatic(req, res, './', './index.html');
    }
}).listen(4448);


const http = require('http');

const fs = require('fs');

const path = require('path');

const mysql = require("mysql");


const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

var loginData, loginMail, baseData;

con.query("CREATE DATABASE IF NOT EXISTS slide_db", (err, result) => {
    if (err) throw err;
    console.log('Database slide_db created');
});


con.query("use slide_db", (err, result) => {
    if (err) throw err;
    console.log("slide_db is using");
});


con.query('CREATE TABLE IF NOT EXISTS slide_tab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255))', (err, result) => {
    if (err) throw err;
    console.log("slide_tab created");
    });


http.createServer(function (req, res) {

    var filePath = '.' + req.url;
    if (filePath == './') {
        filePath = './index.html';
    }
    else if (filePath == "./registration") {
        filePath = "./registration.html";
          req.on("data", (chunk) =>{
                console.log(JSON.parse(chunk));
                console.log("Registration data got on /registration");

                var {firstName, lastName, mail, password} = JSON.parse(chunk);

                var regValue = [[firstName, lastName, mail, password]];

                var inserting = "INSERT INTO slide_tab (firstName, lastName, mail, password) VALUES ?";

                con.query(inserting, [regValue], (err, result) => {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        console.log("data inserted");
                    }
                });
                res.end("Registration was succesfully");
            })
    }
    else if (filePath == "./login") {
        filePath = "./login.html";
    }

    var extname = String(path.extname(filePath)).toLowerCase();
    var mimeTypes = {
        '.html': 'text/html',
        '.js': 'text/javascript',
        '.css': 'text/css',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpg',
        '.gif': 'image/gif',
        '.wav': 'audio/wav',
        '.mp4': 'video/mp4',
        '.woff': 'application/font-woff',
        '.ttf': 'application/font-ttf',
        '.eot': 'application/vnd.ms-fontobject',
        '.otf': 'application/font-otf',
        '.svg': 'application/image/svg+xml'
    };

    var contentType = mimeTypes[extname] || 'application/octet-stream';

    fs.readFile(filePath, function(error, content) {
        if (error) {
            if(error.code == 'ENOENT') {
                fs.readFile('./404.html', function(error, content) {
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.end(content, 'utf-8');
                });
            }
            else {
                res.writeHead(500);
                res.end('Sorry, check with the site admin for error: '+error.code+' ..\n');
                res.end();
            }
        }
        else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });

}).listen(4448);
console.log('Server running at http://127.0.0.1:4448/');
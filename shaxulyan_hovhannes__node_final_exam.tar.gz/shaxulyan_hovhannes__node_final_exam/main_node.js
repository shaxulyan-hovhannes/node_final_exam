const http = require('http');

const fs = require('fs');

const path = require('path');

const loadStatic = require("./custom_modules/load_static_file.js");

const mysql = require("mysql");

const server = http.createServer();


const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

var loginData, loginMail, baseData;

con.query("CREATE DATABASE IF NOT EXISTS slide_db", (err, result) => {
    if (err) throw err;
    console.log('Database slide_db created');
});


con.query("use slide_db", (err, result) => {
    if (err) throw err;
    console.log("slide_db is using");
});


con.query('CREATE TABLE IF NOT EXISTS slide_tab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255))', (err, result) => {
    if (err) throw err;
    console.log("slide_tab created");
    });

server.on("request", (req, res) => {
    if (req.url == "/registration") {
        if (req.method == "POST" && req.url == "/registration") {
             req.on("data", (chunk) =>{
                console.log(JSON.parse(chunk));
                console.log("Registration data got on /registration");

                var {firstName, lastName, mail, password} = JSON.parse(chunk);

                var regValue = [[firstName, lastName, mail, password]];

                var inserting = "INSERT INTO slide_tab (firstName, lastName, mail, password) VALUES ?";

                con.query(inserting, [regValue], (err, result) => {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        console.log("data inserted");
                    }
                });
                res.end("Registration was succesfully");
            })
        }
        else {
        loadStatic(req, res, './registration', './registration.html');
            console.log("1");
            console.log(req.url);
        }
    }
    else if (req.url == "/login") {
        loadStatic(req, res, "./login", "./login.html");
         console.log("2")
         console.log(req.url);
    }
    else {
        loadStatic(req, res, './', './index.html');
         console.log("3")
         console.log(req.url);
    }
}).listen(4448);


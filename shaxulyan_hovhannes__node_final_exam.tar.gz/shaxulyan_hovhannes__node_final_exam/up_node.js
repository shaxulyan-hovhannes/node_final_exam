var formidable = require('formidable'),
    http = require('http'),
    util = require('util');
var fs = require("fs")
 
http.createServer(function(req, res) {
  if (req.url == '/upload' && req.method.toLowerCase() == 'post') {
    // parse a file upload
    var form = new formidable.IncomingForm();
      form.type = true;
      
      form.uploadDir = "./images";
 
    form.parse(req, function(err, fields, files) {
      res.writeHead(200, {'content-type': 'text/plain'});
      res.write('received upload:\n\n');
      res.end(util.inspect({fields: fields, files: files}));
    });
 
    return;
  }
 else {
     fs.readFile("upload.html", (err, data) => {
         res.writeHead(200, {'content-type': 'text/html'});
         if (err) throw err;
         res.write(data);
         res.end();
     })
  // show a file upload form
}
}).listen(8080);

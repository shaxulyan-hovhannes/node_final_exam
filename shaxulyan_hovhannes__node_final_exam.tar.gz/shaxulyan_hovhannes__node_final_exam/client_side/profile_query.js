$(document).ready(function() {
    $(".mainPhoto").on({
        mouseenter: function() {
            $(".mainPhoto div").animate({
                top: "-9.4vh"
            },250)
        },
        mouseleave: function() {
            $(".mainPhoto div").animate({
                top: "1vh"
            },250)
        }
    });
      
    $(".mainPhoto div").children().on({
        mouseenter: function() {
            $(this).css({
                color: "white"
            })
        },
        
        mouseleave: function() {
            $(this).css({
                color: "darkgrey"
            })
        },
        
        click: function() {
            if ($(this).hasClass("delete_photo")) {
                $(".mainPhoto img").removeAttr("src").attr("src", "photo_server/anonym.png");
            }
        }
    });
    
      $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "index.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/"
        }
    });

    $(".nav_menu").children().eq(1).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "registration.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/registration"
        }
    });
    
    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "login.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/login"
        }
    });
    
    /*if ($(".mainPhoto p img").attr("src") == "") {
        $(".mainPhoto p img").attr("src", "photo_server/anonym.png");
    }*/
    //alert($(".mainPhoto p img").attr("src"));
    
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
        $(".user_name").text(data.firstName);
        $(".user_email").text(data.mail);
    }).fail("Error with data getting");
    
     $.ajax({
        url: "http://localhost:4448/all_users",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
       console.log(data);
    }).fail("Error with data getting");
    
    $(".photos").click(function() {
        window.location = "http://localhost:4448/profile_photos"
    })
    
    $(".change_photo").click(function(event) {
        alert()
    })
    
})
$(document).ready(function() {
    $(".mainPhoto").on({
        mouseenter: function() {
            $(".mainPhoto div").animate({
                top: "-9.4vh"
            },250)
        },
        mouseleave: function() {
            $(".mainPhoto div").animate({
                top: "1vh"
            },250)
        }
    });
      
    $(".mainPhoto div").children().on({
        mouseenter: function() {
            $(this).css({
                color: "white"
            })
        },
        
        mouseleave: function() {
            $(this).css({
                color: "darkgrey"
            })
        },
        
        click: function(event) {
            if ($(this).hasClass("delete_photo")) {
                $(".mainPhoto img").removeAttr("src").attr("src", "photo_server/anonym.png");
            }
        }
    });
    
      $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "index.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/"
        }
    });

    $(".nav_menu").children().eq(1).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "registration.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/registration"
        }
    });
    
    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "login.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/login"
        }
    });
    
    /*if ($(".mainPhoto p img").attr("src") == "") {
        $(".mainPhoto p img").attr("src", "photo_server/anonym.png");
    }*/
    //alert($(".mainPhoto p img").attr("src"));
    
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
        console.log(data);
        $(".user_name").text(data.firstName);
        $(".user_email").text(data.mail);
        
        $(".mainPhoto p img").attr("src", data.general_photo);
        
        $(".change_photo").click(function(event) {
            console.log(data);
            var photo = data.photos.split(",");
             console.log(photo)
             $("<div class='photo_col'></div").appendTo($(".wrapper")).css({
                 position: "absolute",
                 width: "26%",
                 height: "79vh",
                 background: "rgba(0, 0, 0, 0.5)"
                });
            $("<p class='close'></p>").appendTo($(".photo_col"));
            $("<span>X</span>").appendTo($(".close"));
            $(".close").css({
                color: "red",
                fontSize: "1.5vw",
                fontWeight: "bold",
                cursor: "pointer"
            })
            for (var i = 1; i < photo.length; i++) {
                $("<img alt='nkar' />").appendTo($(".photo_col")).attr("src", photo[i]).css({
                    "width": "5vw",
                    "transition": "0.3s"
                });
            };
            $(".close").click(function() {
                $(".photo_col").detach();
            });
            
            $(".photo_col img").on({
                mouseenter: function() {
                    $(this).css("transform", "scale(1.7, 1.7)")
                },
                
                mouseleave: function() {
                    $(this).css("transform", "scale(1, 1)")
                }, 
                
                click: function() {
                    //$(".mainPhoto p img").attr("src", $(this).attr("src"));
                    console.log($(this).attr("src"));
                   var tmpObj = {};
                    tmpObj.general_photo = $(this).attr("src");
                    
                    $.ajax({
                        url: "http://localhost:4448/profile",
                        data: JSON.stringify(tmpObj),
                        type: "POST"
                    }).done(function(data) {
                        console.log(data)
                    }).fail(function() {
                        console.log("Error with general photo posting");
                    })
                }
            })
        });
    }).fail("Error with data getting");
    
    $(".photo_col").click(function() {
        alert();
    })
    
     $.ajax({
        url: "http://localhost:4448/all_users",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
       console.log(data);
    }).fail("Error with data getting");
    
    $(".photos").click(function() {
        window.location = "http://localhost:4448/profile_photos"
    })
    
})
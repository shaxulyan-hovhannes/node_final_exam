$(document).ready(function() {
    var login_user, all_users;
    
    $(".mainPhoto").on({
        mouseenter: function() {
            $(".mainPhoto div").animate({
                top: "-9.4vh"
            },250)
        },
        mouseleave: function() {
            $(".mainPhoto div").animate({
                top: "1vh"
            },250)
        }
    });
      
    $(".mainPhoto div").children().on({
        mouseenter: function() {
            $(this).css({
                color: "white"
            })
        },
        
        mouseleave: function() {
            $(this).css({
                color: "darkgrey"
            })
        },
        
        click: function(event) {
            if ($(this).hasClass("delete_photo")) {
                $(".mainPhoto img").removeAttr("src").attr("src", "photo_server/anonym.png");
                
                        $.ajax({
                        url: "http://localhost:4448/profile",
                        data: JSON.stringify({general_photo: "photo_server/anonym.png"}),
                        type: "POST"
                    }).done(function(data) {
                        console.log(data);
                    }).fail(function() {
                        console.log("Error with general photo posting");
                    });
                 location.reload();
            };
        }
    });
    
      $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "index.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/"
        }
    });

    $(".nav_menu").children().eq(1).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "registration.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/registration"
        }
    });
    
    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/profile.html")) != -1) {
            window.location = "login.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile")) != -1) {
            window.location = "http://localhost:4448/login"
        }
    });
    
    /*if ($(".mainPhoto p img").attr("src") == "") {
        $(".mainPhoto p img").attr("src", "photo_server/anonym.png");
    }*/
    //alert($(".mainPhoto p img").attr("src"));
    
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
        login_user = data;
        $(".user_name").text(data.firstName);
        $(".user_email").text(data.mail);
        
        $(".mainPhoto p img").attr("src", data.general_photo);
        
        $(".change_photo").click(function(event) {
            var photo = data.photos.split(",");
             console.log(photo)
             $("<div class='photo_col'></div").appendTo($(".wrapper")).css({
                 position: "absolute",
                 width: "26%",
                 height: "74vh",
                 background: "rgba(128, 128, 128, 0.7)"
                });
            $("<p class='close'></p>").appendTo($(".photo_col"));
            $("<span>X</span>").appendTo($(".close"));
            $(".close").css({
                fontWeight: "bold",
                marginBottom: "1vh",
                color: "red",
                background: "rgba(0, 0, 0, 0.9)",
                fontSize: "2vw",
                cursor: "pointer"
            })
            for (var i = 1; i < photo.length; i++) {
                $("<img alt='nkar' />").appendTo($(".photo_col")).attr("src", photo[i]).css({
                    "width": "5vw",
                    "transition": "0.3s"
                });
            };
            $(".close").click(function() {
                $(".photo_col").detach();
            });
            
            $(".photo_col img").on({
                mouseenter: function() {
                    $(this).css("transform", "scale(1.7, 1.7)")
                },
                
                mouseleave: function() {
                    $(this).css("transform", "scale(1, 1)")
                }, 
                
                click: function() {
                    //$(".mainPhoto p img").attr("src", $(this).attr("src"));
                   var tmpObj = {};
                    tmpObj.general_photo = $(this).attr("src");
                    
                    $.ajax({
                        url: "http://localhost:4448/profile",
                        data: JSON.stringify(tmpObj),
                        type: "POST"
                    }).done(function(data) {
                        console.log(data);
                        location.reload();
                    }).fail(function() {
                        console.log("Error with general photo posting");
                    })
                }
            })
        });
    }).fail("Error with data getting");
    
    
     $.ajax({
        url: "http://localhost:4448/all_users",
        dataType: "json",
        type: "GET"
    }).done(function(data) {
         all_users = data;
         console.log(data);
        // all_users = data;
         for (var i = 0; i < data.length; i++) {
              $("<div></div>").appendTo($(".other_profiles")).css({
                  paddingTop: "0.5vh",
                  width: "23%",
                  height: "23vh",
                  border: "0.1vh inset black",
                  textAlign: "center",
                  marginBottom: "3vh",
                  background:"rgba(0,0,0,0.1)",
                  borderRadius: "1vh", 
                  cursor: "pointer"
             }).append($("<img alt='nkar' />").attr("src", data[i].general_photo).appendTo($(".other_profiles")).css({
                  width: "11vw",
                  height: "15vh",
                  borderRadius: "50%"
             })).append($("<br /><span></span>").text(data[i].firstName)).append($("<br /><span></span>").text(data[i].lastName));
             
             if (data[i].id == login_user.id) {
                 $(".other_profiles div").eq(i).hide();
             }
         };
         
    }).fail("Error with data getting");
    
    setTimeout(function() {
        $(".other_profiles").children().click(function() {
                       $("<div class='slider'></div>").appendTo($(".wrapper")).css({
                position: "absolute",
                zIndex: "1000",
                width: "95vw",
                height: " 80vh",
                background: "rgba(0, 0, 0, 0.6)"
            });
            $("<p>X</p>").css({
                fontWeight: "bold",
                marginBottom: "1vh",
                color: "red",
                background: "rgba(0, 0, 0, 0.9)",
                fontSize: "3vw",
                cursor: "pointer"
            }).appendTo($(".slider"))
        
  
        $(".slider p:first").click(function() {
             $(".slider").detach();
        });
        
    $("<div class='slide_div'></div>").appendTo($(".slider")).css({
        margin: "auto",
        width: "30vw",
        height: "40vh",
        backgroundColor: "gray"
    });
            $("<img src='' alt='nkar' />").appendTo($(".slide_div")).css({
                width: "30vw", 
                height: "40vh"
            });
    
    $("<p class='slide_circles'></p>").appendTo($(".slider")).css({
        margin: "auto",
        marginTop: "1vh",
        width: "30vw",
        display: "flex",
        justifyContent: "space-between",
        flexWrap: "wrap"
    });
           var user_phot = [];
            user_phot.push(all_users[$(this).index()].photos);
            var photos = user_phot[0].split(",");
            
            $(".slide_div img").attr("src", photos[0]);
        
            
                  for (var i = 1; i < photos.length; i++) {
                      if (i == 1) {
                          $(".slide_div img").attr("src", photos[i]);
                      };
              $("<p class='circle'></p>").appendTo($(".slide_circles")).css({
                  width: "20px",
                  height: "20px",
                  background: "gray",
                  borderRadius: "50%",
                  cursor: "pointer"
              }).attr("id", photos[i]);
              $(".slide_circles").children().eq(0).css("border", "0.2vw inset darkgray");
                  }
            $("<p class='btns'></p>").appendTo($(".slider")).css({
                margin: "auto",
                color: "white",
                width: "5vw"
            });
            $("<span><</span>").appendTo($(".btns")).css({
                color: "white",
                float: "left",
                fontWeight: "bold",
                fontSize: "3vw",
                cursor: "pointer"
            });
            
            $("<span>></span>").appendTo($(".btns")).css({
                color: "white",
                float: "right",
                fontWeight: "bold",
                fontSize: "3vw",
                cursor: "pointer"
            });
                        
            var i = 0;
            
            $(".circle").click(function() {
                $(".slide_div img").attr("src", $(this).attr("id"));
                $(this).css("border", "0.2vw inset darkgray");
                $(".slide_circles p").not($(this)).css("border", "none");
                i = $(this).index();
                console.log(i);
            });
            
            $(".btns span:last").click(function(event) {
                $(".btns span:first").css("color", "white");
                if ((i < $(".slide_circles").children().length - 1)) {
                    $(".slide_div img").attr("src", $(".slide_circles").children().eq(++i).attr("id"));
                    $(".slide_circles").children().eq(i).css("border", "0.2vw inset darkgray");
                    $(".slide_circles").children().not($(".slide_circles").children().eq(i)).css("border", "none");
                    console.log(i);
                }
                if (i == $(".slide_circles").children().length-1) {
                    event.preventDefault();
                    $(this).css("color", "red");
                    i = $(".slide_circles").children().length-1;
                }
            })
            
            $(".btns span:first").click(function(event) {
                $(".btns span:last").css("color", "white");
                if ((i > 0) && (i < $(".slide_circles").children().length)) {
                    $(".slide_div img").attr("src", $(".slide_circles").children().eq(--i).attr("id"));
                    $(".slide_circles").children().eq(i).css("border", "0.2vw inset darkgray");
                    $(".slide_circles").children().not($(".slide_circles").children().eq(i)).css("border", "none");
                    console.log(i);
                }
                else {
                    event.preventDefault();
                    $(this).css("color", "red");
                    i = 0;
                }
            })
        })
    }, 200)

    $(".photos").click(function() {
        window.location = "http://localhost:4448/profile_photos"
    })
})
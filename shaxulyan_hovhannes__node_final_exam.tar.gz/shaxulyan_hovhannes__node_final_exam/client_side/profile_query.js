$(document).ready(function() {
    $(".mainPhoto").on({
        mouseenter: function() {
            $(".mainPhoto div").animate({
                top: "-11vh"
            },250)
        },
        mouseleave: function() {
            $(".mainPhoto div").animate({
                top: "0px"
            },250)
        }
    });
    
    $(".mainPhoto img").on({
        mouseenter: function() {
            $(".mainPhoto div").animate({
                top: "0px"
            },250)
        },
        
        mouseleave: function() {
            $(".mainPhoto div").animate({
                top: "-11vh"
            },250)
        }
    });
    
    $(".mainPhoto div").children().on({
        mouseenter: function() {
            $(this).css({
                color: "white"
            })
        },
        
        mouseleave: function() {
            $(this).css({
                color: "darkgrey"
            })
        }
    });
    
})
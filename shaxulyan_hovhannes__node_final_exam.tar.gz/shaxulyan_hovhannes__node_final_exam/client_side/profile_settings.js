$(document).ready(function() {
$(".settings").click(function() {
 $("<div class='profile_settings'></div>").appendTo($(".wrapper")).css({
     position: "absolute",
     zIndex: "1000",
     width: "26%",
     height: "74vh",
     background: "rgba(128, 128, 128, 0.7)",
     textAlign: "center"
 });
    
      $("<p>X</p>").css({
                fontWeight: "bold",
                marginBottom: "1vh",
                color: "red",
                background: "rgba(0, 0, 0, 0.9)",
                fontSize: "3vw",
                cursor: "pointer"
            }).appendTo($(".profile_settings")).click(function() {
           $(".profile_settings").detach();
      });
    
    for (var i = 0; i < 4; i++) {
        $("<input type='text' /> <br />").appendTo($(".profile_settings")).css({
            width: "20vw",
            marginBottom: "2vh",
            fontSize: "2vw",
            background: "rgba(128,128, 128, 0.2)",
            border: "0.2vw inset gray",
            color: "white"
        });
        if (i == 3) {
            for (var j = 0; j < 1; j++) {
                $("<button class='sbmt_btn'>Submit</button>").appendTo($(".profile_settings")).css({
                    width: "8vw",
                    padding: "1vh",
                    borderRadius: "5%"
                });
        }
    }
    };
    

   $(".sbmt_btn").click(function() {
         $(".wrapper").children().find("input").val(function(index, value) {
             if (value.length == 0) {
                 alert("Empty")
             }
         });

    })
    
})
})
   
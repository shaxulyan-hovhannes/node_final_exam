$(document).ready(function() {
    var update_user_data = {}, update_keys = ["firstName", "lastName", "mail", "password"];
$(".settings").click(function() {
 $("<div class='profile_settings'></div>").appendTo($(".wrapper")).css({
     position: "absolute",
     zIndex: "1000",
     width: "26%",
     height: "74vh",
     background: "rgba(128, 128, 128, 0.7)",
     textAlign: "center"
 });
    
      $("<p>X</p>").css({
                fontWeight: "bold",
                marginBottom: "1vh",
                color: "red",
                background: "rgba(0, 0, 0, 0.9)",
                fontSize: "3vw",
                cursor: "pointer"
            }).appendTo($(".profile_settings")).click(function() {
           $(".profile_settings").detach();
      });
    
    for (var i = 0; i < 4; i++) {
        $("<input type='text' /> <br />").appendTo($(".profile_settings")).css({
            width: "24vw",
            marginBottom: "2vh",
            fontSize: "2vw",
            background: "rgba(128,128, 128, 0.2)",
            border: "0.2vw inset gray",
            color: "white",
            padding: "0.2vw"
        });
        if (i == 3) {
            for (var j = 0; j < 1; j++) {
                $("<button class='sbmt_btn'>Change Profile Datas</button> <br />").appendTo($(".profile_settings")).css({
                    width: "13vw",
                    padding: "1vh",
                    borderRadius: "5%",
                    fontWeight: "bold",
                    fontSize: "1.1vw",
                    marginTop: "1.5vh",
                    cursor: "pointer"
                });
                
                $("<button class=delete_profile>Delete Profile</button>").appendTo($(".profile_settings")).css({
                    width: "20vw",
                    padding: "1.5vh",
                    borderRadius: "5%",
                    marginTop: "1.5vh",
                    background: "red",
                    color: "yellow",
                    fontSize: "1.5vw",
                    fontWeight: "bold",
                    cursor: "pointer"
                });
        }
    };
    };
    

   $(".sbmt_btn").click(function(event) {
       if (($("input").eq(0).val().length == 0)
       && ($("input").eq(1).val().length == 0)
       && ($("input").eq(2).val().length == 0)
       && ($("input").eq(3).val().length == 0)){
           event.preventDefault();
           }
       else {
         $(".wrapper").children().find("input").val(function(index, value) {
               update_user_data[update_keys[index]] = value;
         });
       $.ajax({
           url: "http://localhost:4448/profile",
           data: JSON.stringify(update_user_data),
           type: "POST"
       }).done(function(data) {
           alert(data);
           window.location = "http://localhost:4448/login";
       }).fail(function() {
           alert("Error with user_upddate_data posting");
       });
   }
    });
    var message = {
            delete: "Yes"
        };
    
    $(".delete_profile").click(function() {
        var confirming = confirm("Are You sure to delete your profile?", '');
        if (confirming == true) {
        $.ajax({
            url: "http://localhost:4448/profile",
            data: JSON.stringify(message),
            type: "POST"
        }).done(function(data) {
            if (data.indexOf("Your profile have deleted") != -1) {
                alert(data);
                window.location = "http://localhost:4448/login";
            }
        }).fail(function(){
            alert("Error with DELETE MESSAGE posting")
        })
    }
    });
    
})
     console.log(update_user_data)
})
   
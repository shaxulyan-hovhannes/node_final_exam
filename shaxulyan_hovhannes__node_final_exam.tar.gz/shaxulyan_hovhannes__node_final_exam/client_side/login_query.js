$(document).ready(function() {
    $("header ul").children().eq(2).css({
        borderBottom: "0.7vh solid green",
        color: "#08c2c2"
    });


    function isValid(input) {
        input.css("background", "green");
    }

    $(".mail, .password").on({
        keydown: function() {
            if ($(this).val().length == 0) {
                $(this).css("background", "#1d2c38");
            }
        },

        keyup: function() {
            isValid($(this), "green");
        }
    });

    $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/login.html")) != -1) {
            window.location = "index.html";
        }
        if (((window.location.href).indexOf("localhost:4448/login")) != -1) {
            window.location = "http://localhost:4448/"
        }
    });

    $(".nav_menu").children().eq(1).click(function() {
        if (((window.location.href).indexOf("/login.html")) != -1) {
            window.location = "registration.html";
        }
        if (((window.location.href).indexOf("localhost:4448/login")) != -1) {
            window.location = "http://localhost:4448/registration"
        }
    });
})

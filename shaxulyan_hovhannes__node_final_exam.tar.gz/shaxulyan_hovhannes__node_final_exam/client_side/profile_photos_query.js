$(document).ready(function() {
    
      $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/profile_photos.html")) != -1) {
            window.location = "profile.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile_photos")) != -1) {
            window.location = "http://localhost:4448/profile"
        }
    });
    
    $(".nav_menu").children().eq(1).css({
        borderBottom: "0.7vh solid green",
        color: "#08c2c2"
    })

    
    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/slide_show.html")) != -1) {
            window.location = "slide_show.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile_photos")) != -1) {
            window.location = "http://localhost:4448/slide_show"
        }
    });
    
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json", 
        type: "GET"
    }).done(function(data) {
        console.log(data.photos);
        var phot = data.photos.split(",");
        console.log(phot)
    
        for (var i = 1; i < phot.length; i++) {
         $("<div class='image_block'></div>").appendTo($(".photo_gallery"));
        $("<img alt='nkar' />").appendTo($(".image_block")).attr("src", phot[i]);
        }
    }).fail(function() {
        alert("Error with data getting for image_gallery");
    });

        
})
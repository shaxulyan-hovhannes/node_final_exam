$(document).ready(function() {
    
      $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/profile_photos.html")) != -1) {
            window.location = "profile.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile_photos")) != -1) {
            window.location = "http://localhost:4448/profile"
        }
    });
    
    $(".nav_menu").children().eq(1).css({
        borderBottom: "0.7vh solid green",
        color: "#08c2c2"
    })

    
    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/slide_show.html")) != -1) {
            window.location = "slide_show.html";
        }
        if (((window.location.href).indexOf("localhost:4448/profile_photos")) != -1) {
            window.location = "http://localhost:4448/slide_show"
        }
    });
    
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json", 
        type: "GET"
    }).done(function(data) {
        var photos = data.photos.split(" ");
        console.log(photos);
    }).fail(function() {
        alert("Error with data getting for image_gallery");
    });
    
})
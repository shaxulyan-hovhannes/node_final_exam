$(document).ready(function() {
    $("header ul").children().eq(1).css({
        borderBottom: "0.7vh solid green",
        color: "#08c2c2"
    });

    function isError(input, text) {
        input.css("background", "red");
        input.attr("title", text);
    }

    function isValid(input) {
        input.css("background", "green");
        input.removeAttr("title");
    };

    $(".submiting").on({
        mousedown: function() {
            $(this).addClass("flash")
        },
        mouseup: function() {
            $(this).removeAttr("class").attr("class", "submiting").addClass("wow");
        }
    });

    $("input").not($("submiting")).on({
        keydown: function() {
            if ($(this).val().length == 0) {
                $(this).css("background", "#1d2c38");
            }
        },
        keyup: function() {
            if (!$(this).hasClass("submiting")) {
                isValid($(this), "green");
            }

            if ($(this).val().length < 3) {
                isError($(this), "At least 3 letters");
            }

            if ($(this).val().match(/[~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\[\\|\\;\\{\\}\\:\\'\\"\\?\\<\\>\\/\\+\\0\\1\\2\\3\\4\\5\\6\\7\\8\\9]/) && ($(this).attr("class") != "mail") && ($(this).attr("class") != "password") && ($(this).attr("class") != "repeatPassword")) {
                isError($(this), "Type only letters");
            }

            if (($(this).attr("class") == "mail") && (($(".mail").val().indexOf("@") == -1) || ($(".mail").val().indexOf(".") == -1))) {
                isError($(".mail"), "The required symbol [@], or [.] is abcent");
            }


            if ($(".repeatPassword").val() !== $(".password").val()) {
                isValid($(".password"), "green");
                isError($(".repeatPassword"), "Password don't match");
            }
        }
    })

    $(".nav_menu").children().eq(0).click(function() {
        if (((window.location.href).indexOf("/registration.html")) != -1) {
            window.location = "index.html";
        }
        if (((window.location.href).indexOf("localhost:4448/registration")) != -1) {
            window.location = "http://localhost:4448/";
        }
    });

    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/registration.html")) != -1) {
            window.location = "login.html";
        }
        if (((window.location.href).indexOf("localhost:4448/")) != -1) {
            window.location = "http://localhost:4448/login";
        }
    });
})
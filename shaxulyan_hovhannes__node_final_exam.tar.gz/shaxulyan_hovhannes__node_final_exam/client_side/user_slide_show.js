$(document).ready(function() {
     
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json", 
        type: "GET"
    }).done(function(data) {
        console.log(data);
        
        var photos = data.photos.split(",");
        
       photos.each(function(event) {
           
       })
        
        console.log(photos)
    }).fail(function() {
        alert("Error with data getting for user's slide show");
    });
    
})
$(document).ready(function() {
     
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json", 
        type: "GET"
    }).done(function(data) {
        console.log(data);
        
        var photos = data.photos.split(",");
        
        for (var i = 1; i < photos.length; i++) {
            if (i == 1) {
                $(".main_screen_div img").attr("src", photos[i]);
            }
            $("<p class='circle'></span></p").appendTo($(".circles_place")).attr("id", photos[i]);
              $(".circle").eq(0).css("border", "0.3vw solid black");
        }
        
         var i = 0;
        
        $(".circle").click(function() {
             $("span:first").show();
             $("span:last").show();
            $(".main_screen_div img").attr("src", $(this).attr("id"));
            $(this).css("border", "0.3vw solid black");
            $(".circle").not($(this)).css("border", "none");
            i = $(this).index();
            console.log(i);
        });
        
        
         $("span:last").click(function(event) {
             $("span:first").css("color", "black");
             if ((i < $(".circles_place").children().length - 1)) {
            $(".main_screen_div img").attr("src", $(".circle").eq(++i).attr("id"));
                 $(".circle").eq(i).css("border", "0.3vw solid black");
                 $(".circle").not($(".circle").eq(i)).css("border", "none");
                 console.log(i);
             }
             if (i == $(".circles_place").children().length-1) {
                 event.preventDefault();
                 $(this).css("color", "red");
                 i = $(".circles_place").children().length-1;
             }
        })
        
        
         $("span:first").click(function(event) {
             $("span:last").css("color", "black");
             if ((i > 0) && (i < $(".circles_place").children().length)) {
            $(".main_screen_div img").attr("src", $(".circle").eq(--i).attr("id"));
                 $(".circle").eq(i).css("border", "0.3vw solid black");
                $(".circle").not($(".circle").eq(i)).css("border", "none");
                 console.log(i)
             }
             else {
                 event.preventDefault();
                 $(this).css("color", "red");
                 i = 0
             }
        })
        
        console.log(photos)
    }).fail(function() {
        alert("Error with data getting for user's slide show");
    });
    
})
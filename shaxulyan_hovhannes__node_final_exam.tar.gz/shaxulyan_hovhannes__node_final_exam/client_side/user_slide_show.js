$(document).ready(function() {
     
    $.ajax({
        url: "http://localhost:4448/login_user",
        dataType: "json", 
        type: "GET"
    }).done(function(data) {
        console.log(data);
        
        var photos = data.photos.split(",");
        
        for (var i = 1; i < photos.length; i++) {
            if (i == 1) {
                $(".main_screen_div img").attr("src", photos[i])
            }
            $("<p class='circle'></span></p").appendTo($(".circles_place")).attr("id", photos[i]);
        }
        $(".circle").click(function() {
            $(".main_screen_div img").attr("src", $(this).attr("id"));
            console.log($(this).index())
        });
        
        var i = 0;
        
         $("span:last").click(function() {
             $("span:first").show();
             if ((i < $(".circles_place").children().length)) {
            $(".main_screen_div img").attr("src", $(".circle").eq(++i).attr("id"));
                 $(".circle").eq(i).css("border", "0.1vw solid black");
                 console.log(i);
             }
             if (i == $(".circles_place").children().length-1) {
                 $(this).hide();
             }
        })
        
        
         $("span:first").click(function() {
             $("span:last").show();
             if (i < $(".circles_place").children().length) {
            $(".main_screen_div img").attr("src", $(".circle").eq(--i).attr("id"));
                 $(".circle").eq(i).css("border", "0.1vw solid black");
                 console.log(i)
             }
             if (i == 0) {
                 $(this).hide()
             }
        })
        
        console.log(photos)
    }).fail(function() {
        alert("Error with data getting for user's slide show");
    });
    
})
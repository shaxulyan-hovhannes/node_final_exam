$(document).ready(function() {
    $(".nav_menu").children().eq(0).css({
        borderBottom: "0.7vh solid green",
        color: "#08c2c2"
    })

    $("h2").on({
        mouseenter: function() {
            $(this).animate({
                fontSize: "7.5vw",
            },400, function() {
                $(this).animate({
                    fontSize: "7vw"
                }, 300)
            })
        }
    });

    $(".nav_menu").children().eq(1).click(function() {
        if (((window.location.href).indexOf("/index.html")) != -1) {
            window.location = "registration.html";
        }
        if (((window.location.href).indexOf("localhost:4448/")) != -1) {
            window.location = "http://localhost:4448/registration"
        }
    });

    $(".nav_menu").children().eq(2).click(function() {
        if (((window.location.href).indexOf("/index.html")) != -1) {
            window.location = "login.html";
        }
        if (((window.location.href).indexOf("localhost:4448/")) != -1) {
            window.location = "http://localhost:4448/login"
        }
    });
})

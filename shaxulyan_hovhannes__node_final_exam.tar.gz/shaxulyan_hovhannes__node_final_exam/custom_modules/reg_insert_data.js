function regInsertData(chunk, res) {
    console.log(JSON.parse(chunk));
    
    console.log("Registration data got on /registration");
    
    const mysql = require('mysql');
    
    const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
    database: "slide_db"
});

    var {firstName, lastName, mail, password} = JSON.parse(chunk);

    var regValue = [[firstName, lastName, mail, password]];

    var inserting = "INSERT INTO slide_tab (firstName, lastName, mail, password) VALUES ?";

    con.query(inserting, [regValue], (err, result) => {
        if (err) {
            console.log(err);
        }
        else {
            console.log("data inserted");
        }
    });
    res.end("Registration was succesfully");
}


module.exports = regInsertData;
function createConnect_DB_Table() {
    const mysql = require('mysql');
    
    const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

con.query("CREATE DATABASE IF NOT EXISTS slide_db", (err, result) => {
    if (err) throw err;
    console.log('Database slide_db created');
});


con.query("use slide_db", (err, result) => {
    if (err) throw err;
    console.log("slide_db is using");
});

con.query('CREATE TABLE IF NOT EXISTS slide_tab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255))', (err, result) => {
    if (err) throw err;
    console.log("slide_tab created");
    });
};

if (module.parent) {
    module.exports = createConnect_DB_Table;
}
else {
    createConnect_DB_Table();
}
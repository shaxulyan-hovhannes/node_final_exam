function logInData(chunk, res, loginData, loginMail, baseData, con) {
    
     console.log(JSON.parse(chunk));
    
    loginData = JSON.parse(chunk);
                loginMail = loginData["mail"];

                //var sql = "SELECT * FROM rgtab WHERE mail = " + mysql.escape(loginMail);
                var sql = "SELECT * FROM slide_tab WHERE mail = ?";

                var logValue = [loginMail];

                con.query(sql, [logValue], (err, result) => {
                    if (err) throw err;
                    baseData = result;
                    tt = result[0];
                    console.log(tt);
                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] == baseData[0].password)) {
                        res.end("Autorization was succesfully.");
                    }

                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] != baseData[0].password)) {
                        res.end("Wrong password. Please, type correct password.")
                    }

                    if (typeof(baseData[0]) == "undefined") {
                        res.end("There is no user with such as email.")
                    }
                });
}


module.exports = logInData;